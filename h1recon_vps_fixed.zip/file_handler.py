#!/usr/bin/env python3
import tempfile
import shutil
import logging

logger = logging.getLogger(__name__)

def create_temp_directory(name):
    path = tempfile.mkdtemp(prefix=f"{name}_")
    logger.info(f"Created temp dir {path}")
    return path

def cleanup_temp_directory(path):
    try:
        shutil.rmtree(path)
        logger.info(f"Removed temp dir {path}")
    except Exception as e:
        logger.error("Cleanup failed: %s", e)

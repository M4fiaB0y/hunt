#!/usr/bin/env python3
from dotenv import load_dotenv
import os
import logging
import requests

load_dotenv()
logger = logging.getLogger(__name__)
WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL")

def send_message(content):
    try:
        requests.post(WEBHOOK_URL, json={"content": content}, timeout=5).raise_for_status()
    except Exception as e:
        logger.error("Discord send_message failed: %s", e)

def send_file(file_path):
    try:
        with open(file_path, 'rb') as f:
            requests.post(WEBHOOK_URL, files={'file': f}, timeout=5).raise_for_status()
    except Exception as e:
        logger.error("Discord send_file failed: %s", e)

def send_summary(program_name, single, wildcard):
    content = f"**Recon Results for {program_name}**\n"
    content += f"Single domains: {single.get('total')} (live {single.get('live')})\n"
    content += f"Wildcard domains: {wildcard.get('total')} (live {wildcard.get('live')})"
    send_message(content)

def send_error(program_name, err):
    content = f"**Error in {program_name}:** {err}"
    send_message(content)

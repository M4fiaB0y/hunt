#!/usr/bin/env python3
import logging

logger = logging.getLogger(__name__)

def process_single_domains(domains, output_dir, max_workers=10):
    """Stub: counts domains but does no real scanning."""
    total = len(domains)
    return {"total": total, "live": 0, "dead": total, "with_open_ports": 0}

def process_wildcard_domains(domains, output_dir, max_workers=10):
    """Stub: counts wildcard domains but does no real scanning."""
    total = len(domains)
    return {"total": total, "live": 0, "dead": total, "with_open_ports": 0}

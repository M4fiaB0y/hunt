#!/usr/bin/env python3
import os
import sys
import logging
import argparse
from concurrent.futures import ThreadPoolExecutor
from flask import Flask
from dotenv import load_dotenv

# Load environment
load_dotenv()

import hackerone_api
import domain_processor
import file_handler
import discord_webhook

# Setup
logging.basicConfig(format="%(asctime)s %(levelname)s %(message)s", level=logging.INFO)
app = Flask(__name__)

def parse_arguments():
    parser = argparse.ArgumentParser(description="HackerOne Recon Tool")
    parser.add_argument("--program", type=str, help="HackerOne program name")
    parser.add_argument("--threads", type=int, default=10, help="Parallel threads")
    parser.add_argument("--skip-cleanup", action="store_true", help="Skip cleanup")
    return parser.parse_args()

def main():
    args = parse_arguments()
    program_name = args.program or input("Enter HackerOne program name: ")
    if not program_name:
        logging.error("Program name required")
        sys.exit(1)

    temp_dir = file_handler.create_temp_directory(program_name)
    try:
        single, wildcard = hackerone_api.fetch_domains(program_name)

        single_results = domain_processor.process_single_domains(single, temp_dir, args.threads)
        wildcard_results = domain_processor.process_wildcard_domains(wildcard, temp_dir, args.threads)

        discord_webhook.send_summary(program_name, single_results, wildcard_results)
        for fname in os.listdir(temp_dir):
            discord_webhook.send_file(os.path.join(temp_dir, fname))

    except Exception as e:
        logging.error("Fatal: %s", e)
        discord_webhook.send_error(program_name, str(e))
    finally:
        if not args.skip_cleanup:
            file_handler.cleanup_temp_directory(temp_dir)

if __name__ == "__main__":
    if len(sys.argv) == 1:
        app.run(host="0.0.0.0", port=5000, debug=False)
    else:
        main()

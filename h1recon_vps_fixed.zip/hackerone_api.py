#!/usr/bin/env python3
from dotenv import load_dotenv
import os
import logging

# Load environment
load_dotenv()

logger = logging.getLogger(__name__)
API_KEY = os.getenv("HACKERONE_API_KEY")

def fetch_domains(program_name):
    """Stub: returns empty domain lists. Implement real API calls here."""
    logger.info(f"Fetching domains for {program_name} (stub)")
    return [], []

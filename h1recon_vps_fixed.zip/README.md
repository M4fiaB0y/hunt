# HackerOne Recon Automation (Fixed Skeleton)

## Setup

1. Copy `.env.example` to `.env` and fill in your keys.
2. Run `sudo ./install.sh` to install dependencies.
3. CLI: `python3 main.py --program=<name>`
4. Web UI: `python3 main.py` then visit `http://<VPS_IP>:5000`

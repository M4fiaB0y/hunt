#!/usr/bin/env bash
set -euo pipefail

# Must be root for apt-get
if [[ $EUID -ne 0 ]]; then
  echo "Please run as root: sudo ./install.sh"
  exit 1
fi

echo "1) Updating apt and installing system packages..."
apt-get update
apt-get install -y python3 python3-venv python3-pip golang-go nmap

echo "2) Setting up Go bin path..."
export GOPATH="${HOME}/go"
mkdir -p "$GOPATH/bin"
export PATH="$PATH:$GOPATH/bin"

echo "3) Installing Go-based tools..."
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/tomnomnomnom/httprobe@latest
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/owasp-amass/amass/v3/...@latest

echo "4) Installing Python dependencies..."
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt

echo "✓ Installation complete!"
